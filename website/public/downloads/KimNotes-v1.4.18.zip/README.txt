﻿小羊便签 KimNotes v1.4.18
发布日期：2026-10-29

使用：完整解压后运行 KimNotes.exe。请保留同目录的配置文件与 Newtonsoft.Json.dll。
系统：Windows 10 / 11，.NET Framework 4.8，无需 WebView2。
升级：先从托盘退出旧版，再从新文件夹运行。沿用已有便签、图片和账号数据目录。
建议升级前保留本机便签备份；不要在两个文件夹同时运行不同版本。

本次更新：
- 邮箱密码登录、便签与图片双向云同步，新电脑登录可下载到本地。
- 停顿约 2 秒保存；连续输入最长约 5 秒尝试保存。
- 保存后约 10 秒上传，持续编辑最长约 60 秒，空闲约每 60 秒检查云端。
- 新建空白便签不上传；已同步便签清空后同步清空。
- 优化跨屏贴图、缩放残影、便签内图片操作、主题切换与窗口首帧。
- 官网与云端便签页改版，支持按周、月、年分组，保留 LINUX DO 链接。

桌面可离线使用，登录为可选操作。待办和贴图历史目前只保存在本机。
注册打开系统浏览器，桌面登录不显示人机验证。密码不落盘，凭证使用 Windows DPAPI 加密。
网页富文本便签只读，在桌面编辑以保留格式。

发布回归：桌面 385、账号同步 73、同步策略 24、同步边界 12、显示 23、首帧 25 项通过；
图片缩放、图片无损保留与翻译回归通过。该结果不替代所有硬件环境的长期使用验证。

官网：https://note.kimlulu.com/
GitHub：https://github.com/kimlonger/KimNotes/releases/tag/v1.4.18
Gitee：https://gitee.com/xiaoyangkim/KimNotes
更新说明：https://github.com/kimlonger/KimNotes/blob/v1.4.18/docs/release-v1.4.18.md
