小羊便签 KimNotes v1.4.20
适用于 Windows 10 / 11，需安装 .NET Framework 4.8。
请完整解压所有文件，从托盘退出旧版本后运行 KimNotes.exe。
升级前建议备份现有便签数据。
